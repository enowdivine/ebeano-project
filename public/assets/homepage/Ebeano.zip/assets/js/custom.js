$(function () {
  new Swiper(".hero-banner", {
    slidesPerView: 1,
    spaceBetween: 30,
    loop: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    effect: "fade",
    fadeEffect: {
      crossFade: true,
    },
    autoplay: {
      delay: 6000,
    },
  });

  // top product slider
  new Swiper(".top_product_swiper", {
    autoplay: false,
    loop: true,
    spaceBetween: 25,
    slidesPerView: 6,
    slidesPerColumn: 1,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    breakpoints: {
      1359: {
        slidesPerView: 6,
      },
      1023: {
        slidesPerView: 3,
      },
      767: {
        slidesPerView: 3,
      },
      575: {
        slidesPerView: 3,
      },
    },
  });

  new Swiper("#mz-product-listing-37213259", {
    autoplay: false,
    //loop: false,
    spaceBetween: 30,
    slidesPerView: 6,
    slidesPerColumn: 1,
    breakpoints: {
      1359: {
        slidesPerView: 6,
      },
      1023: {
        slidesPerView: 3,
      },
      767: {
        slidesPerView: 3,
      },
      575: {
        slidesPerView: 3,
      },
    },
  });

  // back to top
  $("#back-to-top").click(function (e) {
    e.preventDefault();
    $("html, body").animate({ scrollTop: 0 }, 800);
  });
  window.addEventListener("scroll", function () {
    var el = $("#back-to-top");
    if (window.pageYOffset > window.innerHeight && !el.data("show")) {
      el.data("show", 1);
      el.fadeIn();
    } else if (window.pageYOffset <= window.innerHeight && el.data("show")) {
      el.data("show", 0);
      el.fadeOut();
    }
  });
});
